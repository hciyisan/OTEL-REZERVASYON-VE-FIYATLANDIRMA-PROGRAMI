import java.util.Scanner;

public class HotelReservation {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Initialize room rates and availability
        double[] roomRates = {150.0, 100.0, 75.0};
        boolean[] roomAvailability = {true, true, true};

        // Prompt user for their name and room preferences
        System.out.print("Enter your name: ");
        String guestName = input.nextLine();

        System.out.print("Enter your preferred room type (1 for single, 2 for double, 3 for suite): ");
        int roomType = input.nextInt();

        System.out.print("Enter the number of nights you will be staying: ");
        int numNights = input.nextInt();

        // Check if the selected room type is available
        if (roomAvailability[roomType - 1]) {
            // Calculate the total cost of the reservation
            double totalCost = roomRates[roomType - 1] * numNights;
            System.out.println("Hello, " + guestName + ". Your reservation has been confirmed.");
            System.out.println("Total cost: $" + totalCost);

            // Update the room availability
            roomAvailability[roomType - 1] = false;
        } else {
            System.out.println("Sorry, the selected room type is not available.");
        }
    }
}
